import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5e83e041-4353-4924-ab2d-e33a35ebe79b")
public class Payrolinterface {
    @objid ("d9969166-026e-45f4-8451-d5bbdac5b81d")
    public String PayInfo;

    @objid ("00ab4bb6-ef67-46f5-beda-2f7eb2a35327")
    public void netFromBrut() {
    }

    @objid ("1b3326c1-fd17-4ab0-b00a-17c8bbaa3ea5")
    public void deductionsReport() {
    }

    @objid ("04305fbf-c361-40b6-ad27-47b408c72c16")
    public void impressionChèques() {
    }

}
