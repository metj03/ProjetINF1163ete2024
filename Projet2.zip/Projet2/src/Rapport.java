import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("18f401a7-6fb7-46e5-91c3-d0511d0c2de1")
public class Rapport {
    @objid ("37932637-6e2b-4020-a1b1-1d0b1477401d")
    public String ID;

    @objid ("c33a044d-961a-4f97-ae83-c46f49acf7b7")
    public String Date_creation;

    @objid ("e87de24b-f434-417e-84ba-8bbe3152f27b")
    public String Type_de_rapport;

    @objid ("c7cc82b9-d978-4c8d-b009-57ef5223d8b0")
    public void genererRapport() {
    }

}
