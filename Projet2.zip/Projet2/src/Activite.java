import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d8c03036-4382-4fce-b632-94b101834aae")
public class Activite {
    @objid ("9fbd77e6-df7a-4f41-bbdf-0706e6ad6905")
    public String Date_de_debut;

    @objid ("1451f65a-801e-4860-b846-8f73847c0b5e")
    public String Date_de_fin;

    @objid ("b8767085-bb67-4da4-bfe2-a2855e571464")
    public String Discipline;

    @objid ("92770a6b-ebd9-4082-879a-44684ff48e2f")
    public String Heures_travaillees;

    @objid ("354ca97a-6bf8-4bc0-88ad-624a966972c9")
    public void debuterActivite() {
    }

    @objid ("56c54c5b-625b-4b89-a010-92073d56e1f9")
    public void enregistrerDebut() {
    }

    @objid ("4b51044f-e611-42bf-892c-b928db665f49")
    public void terminerActivite() {
    }

    @objid ("76b9dfac-1738-4f2e-a379-1f39af6040eb")
    public void enregistrerFin() {
    }

}
