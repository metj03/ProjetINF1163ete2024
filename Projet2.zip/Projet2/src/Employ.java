import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("01605b9d-d95e-4d0e-bce8-ed1e8dbf0375")
public class Employé {
    @objid ("55ea909b-fd7b-4c00-8727-93faaffe2e4b")
    public String ID;

    @objid ("4fdde900-1af1-44c5-abba-0e18af04fca0")
    public String Nom;

    @objid ("e35b434e-3ab8-4fe6-9d48-610619554984")
    public String Date_d_embauche;

    @objid ("726161fd-3ff0-4114-b88b-e402150d9133")
    public String Date;

    @objid ("fee90307-8a38-46bf-9aae-a1d99c1e1a3a")
    public String Taux_horaire;

    @objid ("39f4721a-a90c-4c17-88e5-d78d00effda9")
    public String Historique_de_taux_horaire ;

    @objid ("d803604f-c327-4bce-aaeb-4351806e67af")
    public List<Projet>  = new ArrayList<Projet> ();

    @objid ("45b22669-47f2-40e2-a43f-c8ec98b7f2e9")
    public Administrateur ;

    @objid ("77446f00-20dc-4667-8a5e-7f114b88945b")
    public void seConnecter() {
    }

    @objid ("9850cc12-7dc7-48fe-8e38-219a81181e55")
    public void debuterActivite() {
    }

    @objid ("ea3f5b3c-f197-499e-823e-767b77b289ed")
    public void terminerActivite() {
    }

}
