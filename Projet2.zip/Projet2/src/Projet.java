import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5e79b9ca-daf7-477e-bfa6-2f99e3d906aa")
public class Projet {
    @objid ("144f1795-2f73-4c7c-a242-12761826a651")
    public String Id;

    @objid ("1a253d86-d280-4ed9-982e-6464d5b59bfe")
    public String Nom;

    @objid ("dd3fb815-21ca-4834-904f-c7740e7c1fc3")
    public String Date_de_debut;

    @objid ("cca04106-9cac-413c-bf46-b5cbb0530500")
    public String Date_de_fin;

    @objid ("d568febd-aac6-4208-89f5-0d8ecf4359ce")
    public String Heure_budgetees;

    @objid ("88a0746d-3af9-4ab7-9d81-26574d666a8d")
    public String Disciplines;

    @objid ("7c74f381-21e4-4be6-9cdd-8ba4ede6a801")
    public void afficherProjets() {
    }

    @objid ("bc57b450-117b-4262-971e-2096d0c0d072")
    public void afficherDisciplines() {
    }

}
